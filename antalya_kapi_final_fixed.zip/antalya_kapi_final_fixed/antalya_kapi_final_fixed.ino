#include <Keypad.h>
#include <EEPROM.h>
#include <LiquidCrystal_I2C.h>
#include <Wire.h>
#include <MPU6050.h>

#define Pulse 23  
#define Dir 25    
#define Enable 27 
#define Relay 36 
#define Endstop 34 
#define trigPin 30
#define echoPin 32

long delay_Micros = 500;
long steps_per_revolution = 1600;

bool initialDirection = true; // Motorun ilk çalışma yönü
float forwardRotationCount = 2.5; 
int backwardRotationCount = 2;
int repeatCount = 1;
int waitTimeAfterOpen = 5000;
int distancecm = 100; // Engel sensörü mesafesi (cm)
int accelearth = 2; // Deprem hassasiyeti

const byte ROWS = 4;
const byte COLS = 4;

char keys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

byte rowPins[ROWS] = {38, 40, 42, 44}; 
byte colPins[COLS] = {46, 48, 50, 52}; 

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

String password = "1234"; 
String inputPassword = "";

const int buzzerPin = 53;
const int remotePins[] = {51, 49, 47, 45};
int openKey = -1;

String adminPassword1 = "A9999";
String adminPassword2 = "B9999";
String adminPassword3 = "C9999";
String adminPassword4 = "D9999";
bool isAdmin1 = false;
bool isAdmin2 = false;
bool isAdmin3 = false;
bool isAdmin4 = false;

LiquidCrystal_I2C lcd(0x27, 16, 2);

float extraRotation = 0.5;

MPU6050 mpu;
bool earthquakeDetected = false;

void setup() {
  pinMode(Pulse, OUTPUT);
  pinMode(Dir, OUTPUT);
  pinMode(Enable, OUTPUT);
  pinMode(Relay, OUTPUT); 
  pinMode(Endstop, INPUT);
  digitalWrite(Enable, HIGH);
  digitalWrite(Dir, initialDirection ? LOW : HIGH);
  digitalWrite(Relay, HIGH); 

  pinMode(buzzerPin, OUTPUT);
  for (int i = 0; i < 4; i++) {
    pinMode(remotePins[i], INPUT);
  }

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  Serial.begin(9600);
  
  lcd.begin(16, 2);
  lcd.backlight(); 

  password = readPasswordFromEEPROM();
  openKey = EEPROM.read(32);
  waitTimeAfterOpen = EEPROM.read(33) * 1000;
  EEPROM.get(34, forwardRotationCount); // Küsüratlı değeri EEPROM'dan oku

  if (digitalRead(Endstop) == LOW) {
    lcd.clear();
    lcd.print("Kapi Kapaniyor...");
    Serial.println("Kapi Kapaniyor...");
    closeDoor();
  }

  lcd.clear();
  lcd.print("Sifreyi Giriniz:");
  Serial.println("Sifreyi Giriniz:");

  Wire.begin();
  mpu.initialize();
  if (!mpu.testConnection()) {
    Serial.println("MPU6050 baglantisi basarisiz!");
    while (1);
  }
}

void loop() {
  if (!earthquakeDetected) {
    checkEarthquake();
  }

  char key = keypad.getKey();
  if (key) {
    playBeep(1000, 200);

    if (key == '#') {
      if (inputPassword == password) {
        if (earthquakeDetected) {
          earthquakeDetected = false;
          lcd.clear();
          lcd.print("Deprem Modu");
          lcd.setCursor(0, 1);
          lcd.print("Sonlandirildi.");
          Serial.println("Deprem Modu Sonlandirildi.");
          playBeep(1500, 500);
          closeDoor();
        } else {
          lcd.clear();
          lcd.print("Sifre Dogru!");
          lcd.setCursor(0, 1);
          lcd.print("Kapi Aciliyor.");
          Serial.println("Sifre Dogru! Kapi Aciliyor.");
          playBeep(1500, 500);
          
          if (checkObstacle()) {
            lcd.clear();
            lcd.print("Engel Var!");
            lcd.setCursor(0, 1);
            lcd.print("Kapi Acilmiyor.");
            Serial.println("Engel Var! Kapi Acilmiyor.");
            playBeep(500, 500);
          } else {
            openDoor();
          }
        }
      } else if (inputPassword == adminPassword1) {
        lcd.clear();
        lcd.print("Yeni Sifreyi");
        lcd.setCursor(0, 1);
        lcd.print("Giriniz.");
        Serial.println("1. Admin Sifresi Dogru! Yeni Sifreyi Giriniz.");
        inputPassword = "";
        password = "";
        while (true) {
          char newKey = keypad.getKey();
          if (newKey) {
            playBeep(1000, 200);
            if (newKey == '#') {
              Serial.print("Yeni sifre: ");
              Serial.println(password);
              savePasswordToEEPROM(password);
              playBeep(2000, 500);
              break;
            } else {
              password += newKey;
              lcd.clear();
              lcd.print("Yeni Sifre:");
              lcd.setCursor(0, 1);
              lcd.print(password);
              Serial.print(newKey);
            }
          }
        }
        lcd.clear();
        lcd.print("Sifreyi Giriniz:");
        inputPassword = "";
      } else if (inputPassword == adminPassword2) {
        lcd.clear();
        lcd.print("2. Admin Sifresi");
        lcd.setCursor(0, 1);
        lcd.print("Kumanda Tusunu Seciniz.");
        Serial.println("2. Admin Sifresi Dogru! Kumanda Tusunu Seciniz.");
        inputPassword = "";
        
        bool validKey = false;
        while (!validKey) {
          for (int i = 0; i < 4; i++) {
            if (digitalRead(remotePins[i]) == HIGH) {
              openKey = i;
              EEPROM.write(32, openKey);
              lcd.clear();
              lcd.print("Kumanda tusu ");
              lcd.setCursor(0, 1);
              lcd.print(i);
              Serial.print("Açma tusu: ");
              Serial.println(i);
              validKey = true;
              playBeep(2000, 500);
              break;
            }
          }
        }
        
        lcd.clear();
        lcd.print("Sifreyi Giriniz:");
        inputPassword = "";
      } else if (inputPassword == adminPassword3) {
        lcd.clear();
        lcd.print("Acik Kalma");
        lcd.setCursor(0, 1);
        lcd.print("Suresini Girin.");
        Serial.println("3. Admin Sifresi Dogru! Acik Kalma Suresini Giriniz.");
        inputPassword = "";
        
        String tempTime = "";
        while (true) {
          char newKey = keypad.getKey();
          if (newKey) {
            playBeep(1000, 200);
            if (newKey == '#') {
              waitTimeAfterOpen = tempTime.toInt() * 1000;
              EEPROM.write(33, tempTime.toInt());
              Serial.print("Yeni açık kalma süresi: ");
              Serial.println(waitTimeAfterOpen / 1000);
              playBeep(2000, 500);
              break;
            } else {
              tempTime += newKey;
              lcd.clear();
              lcd.print("Acik Kalma:");
              lcd.setCursor(0, 1);
              lcd.print(tempTime);
              lcd.print(" saniye");
            }
          }
        }

        lcd.clear();
        lcd.print("Sifreyi Giriniz:");
        inputPassword = "";
      } else if (inputPassword == adminPassword4) {
        lcd.clear();
        lcd.print("Acilis Turunu");
        lcd.setCursor(0, 1);
        lcd.print("Giriniz.");
        Serial.println("4. Admin Sifresi Dogru! Acilis Turunu Giriniz.");
        inputPassword = "";
        
        String tempRotation = "";
        while (true) {
          char newKey = keypad.getKey();
          if (newKey) {
            playBeep(1000, 200);
            if (newKey == '#') {
              forwardRotationCount = tempRotation.toFloat(); // Küsüratlı değeri float olarak al
              EEPROM.put(34, forwardRotationCount); // Küsüratlı değeri EEPROM'a kaydet
              Serial.print("Yeni açılış turu: ");
              Serial.println(forwardRotationCount);
              playBeep(2000, 500);
              break;
            } else if (newKey == '*') {
              tempRotation += '.'; // * tuşunu ondalık ayracı olarak kullan
              lcd.clear();
              lcd.print("Acilis Turu:");
              lcd.setCursor(0, 1);
              lcd.print(tempRotation);
              lcd.print(" tur");
            } else {
              tempRotation += newKey;
              lcd.clear();
              lcd.print("Acilis Turu:");
              lcd.setCursor(0, 1);
              lcd.print(tempRotation);
              lcd.print(" tur");
            }
          }
        }

        lcd.clear();
        lcd.print("Sifreyi Giriniz:");
        inputPassword = "";
      } else {
        lcd.clear();
        lcd.print("Sifre Hatali!");
        lcd.setCursor(0, 1);
        lcd.print("Tekrar Deneyin.");
        Serial.println("Sifre Hatali! Tekrar Deneyin.");
        playBeep(500, 500);
        
        delay(2000);

        lcd.clear(); 
        lcd.print("Sifreyi Giriniz:");
        Serial.println("Sifreyi Giriniz:");
        inputPassword = "";
      }
      inputPassword = "";
    } else if (key == '*') {
      inputPassword = "";
      lcd.clear();
      lcd.print("Sifre Temizlendi.");
      Serial.println("Sifre Temizlendi.");
    } else {
      inputPassword += key;
      lcd.clear();
      lcd.print("Sifre: ");
      lcd.print(inputPassword);
      Serial.print("Sifre: ");
      Serial.println(inputPassword);
    }
  }

  // Kumanda kontrolünü sadece deprem modu aktif değilse yap
  if (!earthquakeDetected) {
    for (int i = 0; i < 4; i++) {
      if (digitalRead(remotePins[i]) == HIGH) {
        if (i == openKey) {
          lcd.clear();
          lcd.print("Kapi Aciliyor...");
          
          if (checkObstacle()) {
            lcd.clear();
            lcd.print("Engel Var!");
            lcd.setCursor(0, 1);
            lcd.print("Kapi Acilmiyor.");
            Serial.println("Engel Var! Kapi Acilmiyor.");
            playBeep(500, 500);
          } else {
            openDoor();
          }
        }
      }
    }
  }
}

void openDoor() {
  digitalWrite(Relay, LOW); 
  delay(100);
  digitalWrite(Relay, HIGH); 
  digitalWrite(Enable, LOW);
  digitalWrite(Dir, LOW);
  moveMotor((forwardRotationCount + extraRotation) * steps_per_revolution);

  if (!earthquakeDetected) {
    lcd.clear();
    lcd.print("Bekleme...");
    Serial.println("Bekleme...");
    delay(waitTimeAfterOpen);
    closeDoor();
  } else {
    // Deprem modu aktifken ekranda "Deprem Modu Aktif" yazısı kalsın
    lcd.clear();
    lcd.print("Deprem Algilandi");
    lcd.setCursor(0, 1);
    lcd.print("Sifre gir, Kapat ");
  }
}

void closeDoor() {
  digitalWrite(Enable, LOW);
  digitalWrite(Dir, HIGH);

  lcd.clear();
  lcd.print("Kapi Kapaniyor...");
  Serial.println("Kapi Kapanıyor...");

  while (digitalRead(Endstop) == LOW) {
    moveMotor(steps_per_revolution / 10);
  }

  digitalWrite(Enable, HIGH);
  digitalWrite(Relay, HIGH);

  lcd.clear();
  lcd.print("Kapi Kapali.");
  Serial.println("Kapi Kapandi.");

  lcd.clear();
  lcd.print("Sifreyi Giriniz:");
  Serial.println("Sifreyi Giriniz:");
}

void moveMotor(long steps) {
  for (long i = 0; i < steps; i++) {
    if (digitalRead(Endstop) == HIGH && digitalRead(Dir) == HIGH) {
      break;
    }

    digitalWrite(Pulse, HIGH);
    delayMicroseconds(200);
    digitalWrite(Pulse, LOW);
    delayMicroseconds(delay_Micros - 200);
  }
}

void playBeep(int frequency, int duration) {
  tone(buzzerPin, frequency, duration);
  delay(duration);
}

void savePasswordToEEPROM(String password) {
  for (int i = 0; i < password.length(); i++) {
    EEPROM.write(i, password[i]);
  }
  EEPROM.write(password.length(), '\0');
}

String readPasswordFromEEPROM() {
  String password = "";
  for (int i = 0; i < 32; i++) {
    char c = EEPROM.read(i);
    if (c == '\0') break;
    password += c;
  }
  return password;
}

bool checkObstacle() {
  long duration, distance;
  
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  duration = pulseIn(echoPin, HIGH);
  
  distance = duration * 0.034 / 2;
  
  if (distance < distancecm) {
    return true;
  } else {
    return false;
  }
}

void checkEarthquake() {
  int16_t ax, ay, az;
  mpu.getAcceleration(&ax, &ay, &az);

  float ax_g = ax / 16384.0;
  float ay_g = ay / 16384.0;
  float az_g = az / 16384.0;

  float ax_calibrated = ax_g - 0.02;
  float ay_calibrated = ay_g - 0.01;
  float az_calibrated = az_g - 1.00;

  float acceleration = sqrt(ax_calibrated * ax_calibrated + 
                            ay_calibrated * ay_calibrated + 
                            az_calibrated * az_calibrated);

  Serial.print("X: "); Serial.print(ax_calibrated);
  Serial.print(" | Y: "); Serial.print(ay_calibrated);
  Serial.print(" | Z: "); Serial.print(az_calibrated);
  Serial.print(" | Net G: "); Serial.println(acceleration);

  if (acceleration > accelearth) {
    earthquakeDetected = true;
    lcd.clear();
    lcd.print("Deprem Algilandi!");
    lcd.setCursor(0, 1);
    lcd.print("Dikkat Edin!!!");
    Serial.println("Deprem Algilandi! Kapi Acik Konumda.");
    openDoor();
  }
}